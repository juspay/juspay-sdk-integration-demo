<?php

/*
Plugin Name: Juspay Payment Gateway for WooCommerce
Plugin URI: https://juspay.in/
Description:  WooCommerce payment plugin for Juspay.in
Version: 1.2.0
Updated: 11/03/2024
Author: Juspay Technologies
Author URI: https://juspay.in/
License: GPLv2 or later
*/

use PaymentHandler\APIException;
use PaymentHandler\PaymentHandler;
use PaymentHandler\PaymentHandlerConfig;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

require_once __DIR__ . '/includes/juspay-webhook.php';
require_once __DIR__ . '/PaymentHandler.php';

add_action('plugins_loaded', 'juspay_init_payment_class', 0);
add_action('admin_post_nopriv_juspay_wc_webhook', 'juspay_webhook_init', 10);
add_action('before_woocommerce_init', 'juspay_declare_compatibility', 5);

function juspay_init_payment_class()
{

    if (!class_exists('WC_Payment_Gateway')) {
        return;
    }

    class WC_Juspay_Payment extends WC_Payment_Gateway
    {

        protected $paymentHandlerConfig;
        protected $paymentHandler;

        public function __construct()
        {
            $this->id = 'juspay_payment';
            $this->method_title = __('Juspay');
            $this->method_description = __('Allow customers to securely pay via Juspay');
            $this->icon = plugins_url('images/logo.png', __FILE__);

            $this->has_fields = true;

            $this->init_form_fields();
            $this->init_settings();

            switch ($this->get_option('mode')) {
                case "sandbox":
                    $this->base_url = "https://sandbox.juspay.in";
                    break;
                case "production":
                    $this->base_url = "https://api.juspay.in";
                    break;
                default:
                    $this->base_url = "https://sandbox.juspay.in";
                    break;
            }

            try {
                $this->paymentHandlerConfig = PaymentHandlerConfig::getInstance()
                    ->withInstance(
                        $this->get_option('merchant_id'),
                        $this->get_option('api_key'),
                        $this->get_option('client_id'),
                        $this->base_url,
                        false,
                        false,
                        null
                    );
                $this->paymentHandler = new PaymentHandler(null, $this->paymentHandlerConfig);
            } catch (Exception $e) {
                http_response_code(500); // Internal Server Error
                exit();
            }

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->instructions = $this->get_option('instructions');


            $this->notify_url = home_url('/wc-api/wc_juspay');

            add_filter('plugin_action_links_' . plugin_basename(__FILE__), [$this, 'plugin_action_links']);

            add_action('woocommerce_api_wc_juspay', array($this, 'check_juspay_response'));

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));

            add_action("woocommerce_receipt_" . $this->id, array($this, 'receipt_page'));

            add_action('woocommerce_order_actions', array($this, 'juspay_add_manual_actions'));

            add_action('woocommerce_order_action_wc_manual_sync_action', array($this, 'juspay_process_manual_sync_action'));
        }

        public function init_form_fields()
        {

            $webhookUrl = esc_url(admin_url('admin-post.php')) . '?action=juspay_wc_webhook';

            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'label' => 'Enable Juspay Payment Gateway',
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no'
                ),
                'title' => array(
                    'title' => __('Title', 'juspay-payment'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'juspay-payment'),
                    'default' => __("Juspay", 'juspay-payment')
                ),
                'description' => array(
                    'title' => __('Description', 'juspay-payment'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'juspay-payment'),
                    'default' => __('Credit, Debit Card / Net Banking / UPI / Wallets', 'juspay-payment')
                ),
                'mode' => array(
                    'title' => 'Mode',
                    'label' => 'Select Mode',
                    'type' => 'select',
                    'options' => array(
                        'production' => __('Production', 'juspay-payment'),
                        'sandbox' => __('Sandbox', 'juspay-payment'),
                    ),
                    'default' => 'production',
                ),
                'merchant_id' => array(
                    'title' => 'Merchant ID',
                    'label' => 'Enter your Juspay Merchant ID',
                    'description' => 'You can find your merchant ID from the Juspay Dashboard',
                    'type' => 'text'
                ),
                'client_id' => array(
                    'title' => 'Client ID',
                    'type' => 'text',
                ),
                'enable_webhook' => array(
                    'title' => __('Enable Webhook', 'juspay-payment'),
                    'type' => 'checkbox',
                    'description' => "<span>$webhookUrl</span><br/><br/>Use this URL to be entered as Webhook URL on your Juspay dashboard",
                    'label' => __('Enable Juspay Webhook', 'juspay-payment'),
                    'default' => 'no'
                ),
                'webhook_username' => array(
                    'title' => 'Webhook Username',
                    'type' => 'text',
                    'description' => 'You can find your Webhook Url from the settings section of Juspay Dashboard',
                ),
                'webhook_password' => array(
                    'title' => 'Webhook Password',
                    'type' => 'password',
                    'description' => 'You can find your Webhook Password from the settings section of Juspay Dashboard',
                ),
                'api_key' => array(
                    'title' => 'API Key',
                    'type' => 'password',
                    'description' => 'You can find your API Keys from the settings section of Juspay Dashboard',
                ),
            );
        }

        function receipt_page($order_id)
        {
            echo $this->callInitiateJuspayPayment($order_id);
        }

        /**
         * Process the payment and return the result
         **/
        function process_payment($order_id)
        {
            $redirect_url = $this->callInitiateJuspayPayment($order_id, true);
            return array('result' => 'success', 'redirect' => $redirect_url);
        }

        public function check_juspay_response()
        {

            global $woocommerce;

            $msg['class'] = 'error';
            $msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";

            $juspay_order_id = $_REQUEST['order_id'];

            $response = $this->paymentHandler->orderStatus($juspay_order_id);

            $order_id = explode('_', $juspay_order_id);
            $order_id = (int) $order_id[0];

            try {
                $order = new WC_Order($order_id);
                $msg['message'] = $this->getStatusMessage($response);

                if ($response['status'] == 'CHARGED' || $response['status'] == 'COD_INITIATED') {
                    $msg['class'] = 'success';
                } else {
                    $msg['class'] = 'error';
                }

                if ($order->status != 'processing') {
                    if ($response['status'] == "CHARGED" || $response['status'] == "COD_INITIATED") {
                        $order->payment_complete($juspay_order_id);
                        $order->add_order_note('Juspay payment successful.');
                        $woocommerce->cart->empty_cart();
                    } else if ($response['status' == "PENDING_VBV"]) {
                        $woocommerce->cart->empty_cart();
                    }
                }
                $paymentMethod = $response['payment_method'];
                $paymentMethodType = $response['payment_method_type'];
                $order->add_order_note("Payment Method : $paymentMethod ($paymentMethodType)");
            } catch (Exception $e) {
                $msg['class'] = 'error';
                $msg['message'] = "Thank you for shopping with us. However, the transaction has been declined. Please retry payments.";
            }


            if ($msg['class'] != 'success') {
                if (function_exists('wc_add_notice')) {
                    wc_add_notice($msg['message'], $msg['class']);

                } else {
                    $woocommerce->add_error($msg['message']);
                    $woocommerce->set_messages();
                }
            }

            if ($msg['class'] == 'success') {
                $redirect_url = $this->get_return_url($order);
            } else {
                $redirect_url = get_permalink(woocommerce_get_page_id('cart'));
            }
            wp_redirect($redirect_url);
            exit;
        }

        function juspay_add_manual_actions($actions)
        {
            global $theorder;
            $this->method_title = __('Juspay');
            $juspay_order_id = $theorder->get_transaction_id();
            $terminal_status = array("processing", "refunded");
            if (!(in_array($theorder->status, $terminal_status) || strlen($juspay_order_id) < 3)) {
                $actions['wc_manual_sync_action'] = __('Sync Payment with Juspay', 'juspay-payment');
            }
            return $actions;
        }

        function juspay_process_manual_sync_action($order)
        {
            $juspay_order_id = $order->get_transaction_id();
            $response = $this->paymentHandler->orderStatus($juspay_order_id);
            $order->add_order_note('Synced Payment Status : ' . $response['status']);
            if ($response['status'] == 'CHARGED' || $response['status'] == 'COD_INITIATED') {
                if ($order->status != 'processing') {
                    $order->payment_complete($juspay_order_id);
                    $order->add_order_note("Juspay payment successful");
                    $paymentMethod = $response['payment_method'];
                    $paymentMethodType = $response['payment_method_type'];
                    $order->add_order_note("Payment Method : $paymentMethod ($paymentMethodType)");
                }
            }
        }

        function getStatusMessage($order)
        {
            $message = "Your order with order id #" . $order["order_id"] . " and amount " . get_woocommerce_currency() . " " . $order["amount"] . " has the following status: ";
            $status = $order["status"];

            switch ($status) {
                case "CHARGED":
                    $message = $message . "order payment done successfully";
                    break;
                case "PENDING":
                case "PENDING_VBV":
                    $message = $message . "order payment pending";
                    break;
                case "AUTHORIZATION_FAILED":
                    $message = $message . "order payment authorization failed";
                    break;
                case "AUTHENTICATION_FAILED":
                    $message = $message . "order payment authentication failed";
                    break;
                default:
                    $message = $message . "order status " . $status;
                    break;
            }
            return $message;
        }

        public function callInitiateJuspayPayment($order_id, $return_url = false)
        {

            header('Content-Type: application/json');

            $order = wc_get_order($order_id);

            $order_id = strval($order_id);
            $juspay_order_id = $order_id . "_" . substr(hash_hmac('sha512', $order_id, time() . ""), 0, 16);

            $order->set_transaction_id($juspay_order_id);
            $order->save();

            $customer = wp_get_current_user();

            if ($customer->ID === 0) {
                $customer_id = "guest";
                $customer_id_hash = substr(hash_hmac('sha512', $customer_id, time() . ""), 0, 16);
                $customer_id = "guest_" . $customer_id_hash;
            } else {
                $customer_id = $customer->ID . "";
                $customer_registered = $customer->user_registered;
                $customer_id_hash = substr(hash_hmac('sha512', $customer_id, $customer_registered . ""), 0, 16);
                $customer_id = "cust_" . $customer_id_hash;
            }

            $amount = (int) ($order->get_total());
            try {
                $params = array();
                $params['amount'] = $amount;
                $params['currency'] = get_woocommerce_currency();
                $params['order_id'] = $juspay_order_id;
                $params['udf1'] = "WooCommerce";
                $params["merchant_id"] = $this->get_option('merchant_id');
                $params['customer_id'] = $customer_id;
                $params['payment_page_client_id'] = $this->get_option('client_id');
                $params['action'] = "paymentPage";
                $params['return_url'] = $this->notify_url . '/?order_id=' . $juspay_order_id;

                $response = array();
                try {
                    $session = $this->paymentHandler->orderSession($params);

                    $response = array("orderId" => $session["order_id"], "id" => $session["id"], "status" => $session["status"], "paymentLinks" => $session["payment_links"], "sdkPayload" => $session["sdk_payload"]);
                } catch (Exception $e) {
                    http_response_code(500); // Internal Server Error
                    exit();
                }
            } catch (APIException $e) {
                http_response_code(500); // Internal Server Error
                exit();
            }

            $redirectUrl = $response['paymentLinks']['web'];

            if ($return_url) {
                return $redirectUrl;
            } else {
                header("Location: $redirectUrl");
            }
            exit();
        }

        function plugin_action_links($links)
        {
            $plugin_links = [
                '<a href="admin.php?page=wc-settings&tab=checkout&section=juspay_payment">' . esc_html__('Settings', 'juspay-payment') . '</a>',
            ];
            return array_merge($plugin_links, $links);
        }
    }

    function juspay_add_payment_class($gateways)
    {
        $gateways[] = 'WC_Juspay_Payment';
        return $gateways;
    }

    add_filter('woocommerce_payment_gateways', 'juspay_add_payment_class');

}

// This is set to a priority of 10
function juspay_webhook_init()
{
    $jpWebhook = new Juspay_Webhook();
    $jpWebhook->process();
}

function juspay_declare_compatibility()
{
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
}